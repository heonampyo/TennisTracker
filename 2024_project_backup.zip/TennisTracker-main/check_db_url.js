// check_db_url.js
require('dotenv').config();
console.log(process.env.DATABASE_URL);