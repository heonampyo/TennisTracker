-- AlterTable
ALTER TABLE "User" ADD COLUMN     "fcmToken" TEXT;
